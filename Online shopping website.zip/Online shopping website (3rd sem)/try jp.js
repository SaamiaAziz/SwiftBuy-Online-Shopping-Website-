
let cart = []; // Initialize the cart array
let cartCount = document.getElementById('cartCount');  // Element to display the cart count

// Update cart count in the header
function updateCartCount() {
    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    document.getElementById('cartCount').textContent = cart.length;
}

// Add item to cart
function addToCart(event) {
    let productElement = event.target.closest('.product-card, .deal-card');
    let id = productElement.getAttribute('data-id');
    let name = productElement.getAttribute('data-name');
    let price = productElement.getAttribute('data-price');

    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    cart.push({ id, name, price});
    localStorage.setItem('cart', JSON.stringify(cart));

    updateCartCount();
}


// Display cart items
function displayCart() {
    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    let cartItemsContainer = document.getElementById('cartItems');
    let totalPrice = 0;

    cartItemsContainer.innerHTML = '';  // Clear existing items

    if (cart.length === 0) {
        cartItemsContainer.innerHTML = '<p>Your cart is empty.</p>';
        document.getElementById('checkoutBtn').disabled = true;
        return;
    }

    cart.forEach(item => {

        let itemElement = document.createElement('div');
        itemElement.classList.add('cart-item');
        itemElement.innerHTML = `
            <div>
                <h4>${item.name}</h4>
                <p>$${item.price}</p>
                <button class="remove-item" data-id="${item.id}">Remove</button>
            </div>
        `;
        cartItemsContainer.appendChild(itemElement);
        totalPrice += parseFloat(item.price);
    });
    
    document.getElementById('totalPrice').textContent = totalPrice.toFixed(2);
    document.getElementById('checkoutBtn').disabled = cart.length === 0;
}

// Remove item from cart
function removeFromCart(itemid) {
    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    cart = cart.filter(item => item.id !== itemid);
    localStorage.setItem('cart', JSON.stringify(cart));
    displayCart();
    updateCartCount();
}


// Event listeners for add to cart buttons
document.querySelectorAll('.add-to-cart').forEach(button => {
    button.addEventListener('click', addToCart);
});

// Event listener for remove from cart buttons
document.getElementById('cartItems').addEventListener('click', function(event) {
    if (event.target.classList.contains('remove-item')) {
        let itemId = event.target.getAttribute('data-id');
        removeFromCart(itemId);
    }
});

// Initialize cart display on page load
window.onload = function() {
    updateCartCount();
    displayCart();
};




// Function to handle proceeding to checkout
function proceedToCheckout() {
    if (cart.length == 0) {
        alert("Thanks for Shopping! ");
        return;
    }

    const checkoutSection = document.getElementById("checkout-section");
    const checkoutItemsContainer = document.getElementById("checkout-items");

    checkoutItemsContainer.innerHTML = ''; // Clear previous checkout items

    // Add cart items to checkout section
    cart.forEach(item => {
        const checkoutItem = document.createElement('div');
        checkoutItem.classList.add('checkout-items');
        checkoutItem.innerHTML = `
            <span>${item.name} - ${item.price} PKR x ${item.quantity}</span>
        `;
        checkoutItemsContainer.appendChild(checkoutItem);
    });

    // Show the checkout section and hide the cart section
    document.querySelector('.cart-section').style.display = 'none'; // Assuming your cart section has the class "cart-section"
    checkoutSection.style.display = 'block';  // Show the checkout section
}


// Attach event listener to checkout button
document.getElementById('checkoutButton')?.addEventListener('click', proceedToCheckout);


function completePurchase() {
    alert("Thank you for your purchase!");
    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    updateCart(); // Update the cart display
    document.getElementById("checkout-section").style.display = 'none'; // Hide the checkout section
    document.querySelector('.cart').style.display = 'block'; // Show the cart again
}

function cancelCheckout() {
    // Hide the checkout section and show the cart again
    document.getElementById("checkout-section").style.display = 'none';
    document.querySelector('.cart').style.display = 'block';
}
 

